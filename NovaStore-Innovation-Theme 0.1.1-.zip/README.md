# NovaStore — James Innovation

NovaStore is an original Shopify Online Store 2.0 theme starter for fashion, clothing and lifestyle merchants.

## Included in this first development build
- Responsive premium editorial design system (cream, white, charcoal, taupe)
- Customizable header, footer, hero, editorial text and featured collection sections
- Product, collection, cart, page and search templates
- Three alternate homepage layouts: `index.nova-fashion.json`, `index.nova-lifestyle.json`, `index.nova-minimal.json`
- Theme settings for core colors, heading style and page width

## Important status
This is **development build 0.1.0**, not a finished or Shopify Theme Store-approved product. Before selling it, the theme needs full browser testing in a Shopify development store, accessibility and performance audits, cross-browser checks, richer product variant/media interactions, localization review, documentation, demo content and a complete Shopify Theme Store requirements review.

The header and footer groups and JSON templates follow Shopify's Online Store 2.0 theme architecture. Homepage alternates can be used as alternate index templates where supported by the store's theme editor workflow; confirm the selection process in the target development store.

## Install for development
1. Create or use a Shopify development store.
2. Upload the ZIP through **Online Store → Themes → Add theme → Upload zip file**, or use Shopify CLI (`shopify theme dev`) from a computer environment.
3. Open **Customize** and choose a collection for the Featured collection section.
4. Add a hero image and connect the main menu.
5. Add products and collections to the store before evaluating the storefront.

## Brand
James Innovation — NovaStore.
